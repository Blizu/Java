public class S16710_zestaw10{

    public static void main (String args[]) {

        Dzem dzem1 = new Dzem ("truskawkowy",100);
        Dzem dzem2 = new Dzem(100);
        Dzem dzem3 = new Dzem ("pożeczkowy");

        System.out.println(dzem1.toString());
        System.out.println(dzem2.toString());
        System.out.println(dzem3.toString());
        System.out.println();

        Sloik sloik1 = new Sloik(false,dzem1);
        Sloik sloik2 = new Sloik(false,dzem2);
        Sloik sloik3 = new Sloik (false,dzem3);
        System.out.println(sloik1.toString());
        System.out.println(sloik2.toString());
        System.out.println(sloik3.toString());
        System.out.println();

        Wyraz wyraz = new Wyraz("Ala ");
        wyraz.setNastepnyWyraz("ma ")
                .setNastepnyWyraz("kota ")
                .setNastepnyWyraz("a ")
                .setNastepnyWyraz("kot ")
                .setNastepnyWyraz("ma ")
                .setNastepnyWyraz("Ale ");
        System.out.println(wyraz.show());

    }
}
