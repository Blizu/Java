

public class Sloik {
    Dzem dzem;
    boolean otwarty;

    Sloik(boolean czyOtwarty, Dzem rodzaj){//w konstruktorze powinno byc sprawdzenie czy słoik jest otwarty jak nie to go otworzyc, napelnic i zamknac
        otwarty = czyOtwarty();
        if(czyOtwarty==false) {
            otworz();
            this.dzem = rodzaj;
            zamknij();
        }
    }

    boolean otworz(){
        return otwarty = true;
    }

    boolean zamknij(){
        return otwarty = false;
    }

    boolean czyOtwarty(){
        return otwarty;
    }

    public String toString(){
        return "Słoik z dżemem " + dzem.smak + " o wadze "+dzem.waga;

    }
}

