public class Wyraz {

    String wyrazPoczatkowy;
    Wyraz nastepnyWyraz;

    public Wyraz(String wyraz) {
        this.wyrazPoczatkowy = wyraz;
    }

    public Wyraz setNastepnyWyraz(String nastepnyWyraz) {
        this.nastepnyWyraz = new Wyraz(nastepnyWyraz);
        return this.nastepnyWyraz;
    }

    public String show() {
        String wyrazReturn = this.wyrazPoczatkowy;
        if (this.nastepnyWyraz != null) {
            wyrazReturn += this.nastepnyWyraz.show();
        }
        return wyrazReturn;
    }
}
