

public class Dzem {

    String smak;
    double waga;

    public Dzem(String smak, double waga){
        this.smak=smak;
        this.waga=waga;
    }

    public Dzem(double waga){
        this("no name",waga);
    }

    public Dzem(String smak){
        this(smak,-100.0);
    }

    public String toString(){
        return "Dżem "+ smak +" "+ "waga: " + waga;
    }



}
