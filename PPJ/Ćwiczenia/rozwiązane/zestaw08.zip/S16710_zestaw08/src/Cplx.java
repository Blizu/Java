public class Cplx {

    private double Re;
    private double Im;

    public Cplx(double Re, double Im) {
        this.Re = Re;
        this.Im = Im;
    }

    public void show() {
        char plus = '+';

        if (Im >= 0)
            System.out.println("Liczba zespolona: " + Re + plus + Im + "i");

        else
            System.out.println("Liczba zespolona: " + Re + "" + Im + "i");
    }

    public void add(Cplx cplx) {
        Re = Re + cplx.Re;
        Im = Im + cplx.Im;
    }

    public void sub(Cplx cplx) {
        Re = Re - cplx.Re;
        Im = Re - cplx.Im;
    }

    public void mul(Cplx cplx) {
        Re = (Re * cplx.Re) - (Im * cplx.Im);
        Im = (cplx.Re * Im) + (Re * cplx.Im);
    }

    public void inc() {
        Re = Re + 1;
    }
}

