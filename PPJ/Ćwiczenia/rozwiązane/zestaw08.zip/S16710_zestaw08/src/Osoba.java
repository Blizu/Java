public class Osoba {
    public String imie;
    public String nazwisko;
    public int rokUrodzenia;



    public Osoba(String imie, String nazwisko, int rokUrodzenia){
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.rokUrodzenia=rokUrodzenia;
    }

    public Osoba() {}

    public void show(){
        System.out.println(imie+" "+nazwisko+" "+rokUrodzenia);
        System.out.println();
    }
}
