public class Number {
    public int x;

    public Number(){}

    public void setValue(int liczba){
        this.x=liczba;

    }
    public int showValue(){
        return x;
    }
}
