public class main {
    public static void main(String args[]){

        MethodCurrier methodCurrier = new MethodCurrier();
        methodCurrier.setValue(5);
        methodCurrier.setValue(10.0f);

        Number number = new Number();
        number.setValue(10);
        Number number1 = new Number();
        number1.setValue(5);
        methodCurrier.setValue(number.x);
        methodCurrier.setValue(number1.x);


        System.out.println("===============");
        Osoba osoba1 = new Osoba();
        osoba1.imie = "Adam";
        osoba1.nazwisko ="Mickiewicz";
        osoba1.rokUrodzenia=1798;
        Osoba osoba2 = new Osoba("Juliusz","Słowacki",1809);
        osoba1.show();
        osoba2.show();
        System.out.println("===============");
        Cplx para1 = new Cplx(2, 3);
        Cplx para2 = new Cplx(2, 1);
        Cplx para3 = new Cplx(4, 10);
        para1.show();
        para2.show();
        para1.add(para2);
        para1.show();
        para1.sub(para2);
        para1.show();
        para2.sub(para3);
        para2.show();
        para1.mul(para3);
        para1.show();
        para1.inc();
        para1.show();

    }
}
