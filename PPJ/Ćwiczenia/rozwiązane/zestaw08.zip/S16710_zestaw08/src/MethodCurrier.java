public class MethodCurrier {



    public MethodCurrier() {

    }

    public void setValue(int liczba) {
        System.out.println("Dostarczona wartość to: " + liczba + "\n" + "Dostarczony parametr jest typu integer");
        liczba = liczba * (int) (Math.random() * 10) + 1;
        System.out.println("Wartość po zmianie: " + liczba);
        System.out.println();
    }

    public void setValue(float liczba) {
        System.out.println("Podana wartość to: " + liczba + "\n" + "Dostarczony parametr jest typu float");
        liczba = liczba * (int) (Math.random() * 10) + 1;
        System.out.println("Wartość po zmianie: " + liczba);
        System.out.println();
    }


    public void setValue(Number number) {
        System.out.println("Podana wartość to: " + number+ "\n" + "Dostarczony parametr jest typu Number");
        System.out.println("Wartość po zmianie: " + number);
        System.out.println();
    }
}

    /*
    Odp na pytanie

   Decyzja podejmowana jest na podstawie typu zmiennej, która została dostarczona.
   Dzięki przeciążaniu metod możemy je nazwyać tak samo, lecz dla każdej z nich musimy przewidzieć jakiego rodzaju parametry bedą przyjmować.
     */

